package com.example.taskTwoThree.HeadService.ReaderService;

import java.util.List;

import com.example.taskTwoThree.entity.EmployeeEntity;

public interface ReaderService {
	
	public List<EmployeeEntity> getData();
}
