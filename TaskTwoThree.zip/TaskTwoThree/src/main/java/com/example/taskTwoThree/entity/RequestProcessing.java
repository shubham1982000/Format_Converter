package com.example.taskTwoThree.entity;

public class RequestProcessing {

	private String readerCriteria;
	private String writerCriteria;

	public String getReaderCriteria() {
		return readerCriteria;
	}

	public void setReaderCriteria(String readerCriteria) {
		this.readerCriteria = readerCriteria;
	}

	public String getWriterCriteria() {
		return writerCriteria;
	}

	public void setWriterCriteria(String writerCriteria) {
		this.writerCriteria = writerCriteria;
	}

}
