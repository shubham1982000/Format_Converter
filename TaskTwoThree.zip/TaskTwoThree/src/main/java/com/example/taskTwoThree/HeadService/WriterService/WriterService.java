package com.example.taskTwoThree.HeadService.WriterService;

import java.util.List;

import com.example.taskTwoThree.entity.EmployeeEntity;

public interface WriterService {

	public void writeData(List<EmployeeEntity> employeeList);
}
