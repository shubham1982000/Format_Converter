package com.example.taskTwoThree.entity;

public enum ReadCriteriaEnum {
	EXCELREAD, DBREAD;

}
