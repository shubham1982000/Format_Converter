package com.example.taskTwoThree.entity;

public enum WriteCrireriaEnum {
	EXCELWRITE, CSVWRITE, XMLWRITE, PIPEWRITE, DBWRITE;

}
